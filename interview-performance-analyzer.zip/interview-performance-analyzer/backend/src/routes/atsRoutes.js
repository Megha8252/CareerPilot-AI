import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import {
  analyzeResume,
  atsUploadMiddleware,
  generateQuestions,
  getAtsReport,
  getResume,
  listAtsReports,
  listResumes,
  matchJob,
  uploadResume
} from "../controllers/atsController.js";

export const atsRoutes = Router();
atsRoutes.use(requireAuth);

// Resumes
atsRoutes.post("/resumes", atsUploadMiddleware, uploadResume);
// Aliases (as requested)
atsRoutes.post("/upload-resume", atsUploadMiddleware, uploadResume);

atsRoutes.get("/resumes", listResumes);
atsRoutes.get("/resumes/:id", getResume);

// ATS analysis + job matching
atsRoutes.post("/analyze", analyzeResume);
atsRoutes.post("/match", matchJob);
// Aliases (as requested)
atsRoutes.post("/analyze-resume", analyzeResume);
atsRoutes.post("/match-job", matchJob);

// Reports
atsRoutes.get("/reports", listAtsReports);
atsRoutes.get("/reports/:id", getAtsReport);

// Questions
atsRoutes.post("/questions", generateQuestions);
// Alias (as requested)
atsRoutes.post("/generate-questions", generateQuestions);
