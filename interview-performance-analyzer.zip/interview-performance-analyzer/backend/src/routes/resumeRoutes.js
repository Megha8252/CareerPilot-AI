import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import { parseResume, resumeUploadMiddleware } from "../controllers/resumeController.js";

export const resumeRoutes = Router();
resumeRoutes.use(requireAuth);

resumeRoutes.post("/parse", resumeUploadMiddleware, parseResume);

