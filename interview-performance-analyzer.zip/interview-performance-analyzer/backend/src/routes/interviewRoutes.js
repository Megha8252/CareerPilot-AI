import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import {
  generateReport,
  getInterview,
  listInterviews,
  startInterview,
  submitAnswer
} from "../controllers/interviewController.js";

export const interviewRoutes = Router();

interviewRoutes.use(requireAuth);

interviewRoutes.post("/", startInterview);
interviewRoutes.get("/", listInterviews);
interviewRoutes.get("/:id", getInterview);
interviewRoutes.post("/:id/answer", submitAnswer);
interviewRoutes.post("/:id/report", generateReport);

