import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import { dashboardStats, getLatestReportForInterview, getReport } from "../controllers/reportController.js";

export const reportRoutes = Router();
reportRoutes.use(requireAuth);

reportRoutes.get("/dashboard", dashboardStats);
reportRoutes.get("/by-interview/:interviewId", getLatestReportForInterview);
reportRoutes.get("/:id", getReport);
