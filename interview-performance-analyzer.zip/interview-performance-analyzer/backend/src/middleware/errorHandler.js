// Centralized error handler (production-friendly)
export function errorHandler(err, req, res, next) {
  // Zod validation errors => 400
  if (err?.name === "ZodError" && Array.isArray(err?.issues)) {
    return res.status(400).json({
      success: false,
      message: "Validation error",
      errors: err.issues
    });
  }

  // Mongo duplicate key errors (e.g., unique email)
  if (err?.code === 11000) {
    return res.status(409).json({
      success: false,
      message: "Duplicate key",
      key: err?.keyValue
    });
  }

  const status = err.statusCode || err.status || 500;
  const message = err.message || "Internal Server Error";

  // eslint-disable-next-line no-console
  console.error("❌ Error:", err);

  res.status(status).json({
    success: false,
    message,
    ...(process.env.NODE_ENV === "production"
      ? {}
      : { stack: err.stack, details: err.details })
  });
}
