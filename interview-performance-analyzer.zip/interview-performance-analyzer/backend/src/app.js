import express from "express";
import cors from "cors";
import morgan from "morgan";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { env } from "./config/env.js";
import { authRoutes } from "./routes/authRoutes.js";
import { interviewRoutes } from "./routes/interviewRoutes.js";
import { reportRoutes } from "./routes/reportRoutes.js";
import { resumeRoutes } from "./routes/resumeRoutes.js";
import { atsRoutes } from "./routes/atsRoutes.js";
import { errorHandler } from "./middleware/errorHandler.js";

export function createApp() {
  const app = express();

  app.use(helmet());
  const allowedOrigins =
    env.CLIENT_ORIGIN === "*"
      ? "*"
      : env.CLIENT_ORIGIN.split(",")
          .map((s) => s.trim())
          .filter(Boolean);

  app.use(
    cors({
      origin(origin, cb) {
        // Allow non-browser clients (curl/postman) with no origin header
        if (!origin) return cb(null, true);
        if (allowedOrigins === "*") return cb(null, true);
        if (allowedOrigins.includes(origin)) return cb(null, true);
        return cb(new Error(`CORS blocked for origin: ${origin}`));
      },
      credentials: true
    })
  );
  app.use(express.json({ limit: "1mb" }));
  app.use(morgan("dev"));

  app.use(
    "/api",
    rateLimit({
      windowMs: 60 * 1000,
      limit: 120,
      standardHeaders: "draft-7",
      legacyHeaders: false
    })
  );

  app.get("/health", (req, res) => res.json({ ok: true }));

  app.use("/api/auth", authRoutes);
  app.use("/api/interviews", interviewRoutes);
  app.use("/api/reports", reportRoutes);
  app.use("/api/resume", resumeRoutes);
  app.use("/api/ats", atsRoutes);

  app.use(errorHandler);
  return app;
}
