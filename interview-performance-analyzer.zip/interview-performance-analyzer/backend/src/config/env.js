import dotenv from "dotenv";
import { z } from "zod";

dotenv.config();

const schema = z.object({
  PORT: z.coerce.number().default(5000),
  MONGODB_URI: z.string().min(1),
  JWT_SECRET: z.string().min(20),
  JWT_EXPIRES_IN: z.string().default("7d"),

  OPENAI_API_KEY: z.string().optional(),
  OPENAI_MODEL: z.string().default("gpt-4o-mini"),

  CLIENT_ORIGIN: z.string().default("http://localhost:5173"),
  MAX_RESUME_SIZE_BYTES: z.coerce.number().default(4_000_000)
});

export const env = schema.parse(process.env);

