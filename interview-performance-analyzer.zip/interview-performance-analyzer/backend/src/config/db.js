import mongoose from "mongoose";
import { env } from "./env.js";
import { MongoMemoryServer } from "mongodb-memory-server";

export async function connectDb() {
  mongoose.set("strictQuery", true);
  if (env.MONGODB_URI === "memory") {
    const mongod = await MongoMemoryServer.create();
    const uri = mongod.getUri();
    await mongoose.connect(uri, { autoIndex: true });
    // eslint-disable-next-line no-console
    console.log("✅ MongoDB Memory Server started");
    return;
  }

  await mongoose.connect(env.MONGODB_URI, { autoIndex: true });
  // eslint-disable-next-line no-console
  console.log("✅ MongoDB connected");
}
