import bcrypt from "bcryptjs";
import { connectDb } from "../config/db.js";
import { User } from "../models/User.js";
import { Interview } from "../models/Interview.js";
import { Report } from "../models/Report.js";

async function seed() {
  await connectDb();

  await Promise.all([User.deleteMany({}), Interview.deleteMany({}), Report.deleteMany({})]);

  const passwordHash = await bcrypt.hash("password123", 10);
  const user = await User.create({
    name: "Demo Student",
    email: "demo@student.com",
    passwordHash
  });

  const interview = await Interview.create({
    userId: user._id,
    domain: "HR",
    mode: "text",
    status: "completed",
    maxQuestions: 3,
    turns: [
      {
        question: "Tell me about yourself.",
        answer:
          "I'm a final-year CS student focused on full-stack development. I enjoy building products and improving user experience.",
        responseTimeMs: 22000,
        metrics: {
          clarityScore: 7.5,
          confidenceScore: 7,
          grammarScore: 8,
          relevanceScore: 8,
          feedback: "Good concise introduction. Add a specific project example to be stronger.",
          improvementTips: ["Mention 1-2 projects and your impact."],
          redFlags: []
        }
      },
      {
        question: "Why do you want this role?",
        answer:
          "Because I want to work on impactful software with a strong team and learn best practices in production engineering.",
        responseTimeMs: 18000,
        metrics: {
          clarityScore: 7,
          confidenceScore: 7,
          grammarScore: 8,
          relevanceScore: 7,
          feedback: "Clear motivation. Make it more company-specific and role-specific.",
          improvementTips: ["Reference the company/product and map skills to role requirements."],
          redFlags: []
        }
      },
      {
        question: "What is your biggest strength and biggest weakness?",
        answer:
          "My strength is persistence and problem solving. My weakness is I sometimes over-polish details, but I manage it by timeboxing.",
        responseTimeMs: 26000,
        metrics: {
          clarityScore: 7,
          confidenceScore: 7.5,
          grammarScore: 8,
          relevanceScore: 8,
          feedback: "Strong framing. Consider adding evidence of your strength with an example.",
          improvementTips: ["Use the STAR format for at least one part of the answer."],
          redFlags: []
        }
      }
    ]
  });

  const report = await Report.create({
    userId: user._id,
    interviewId: interview._id,
    strengths: ["Clear answers", "Good grammar and fluency"],
    weaknesses: ["Needs more specific examples", "Company-specific motivation could be stronger"],
    suggestions: ["Prepare 3 STAR stories", "Research the company and tailor your pitch"],
    finalVerdict: "Needs Improvement",
    summary:
      "Solid baseline communication. Add more concrete examples and tailor answers for stronger impact.",
    overallScores: { clarity: 7.2, confidence: 7.2, grammar: 8, relevance: 7.7 }
  });

  // eslint-disable-next-line no-console
  console.log("✅ Seed complete");
  // eslint-disable-next-line no-console
  console.log("Demo user:", { email: "demo@student.com", password: "password123" });
  // eslint-disable-next-line no-console
  console.log("Interview ID:", interview._id.toString());
  // eslint-disable-next-line no-console
  console.log("Report ID:", report._id.toString());
  process.exit(0);
}

seed().catch((err) => {
  // eslint-disable-next-line no-console
  console.error(err);
  process.exit(1);
});

