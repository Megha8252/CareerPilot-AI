import mongoose from "mongoose";

const atsReportSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", index: true, required: true },
    resumeId: { type: mongoose.Schema.Types.ObjectId, ref: "Resume", index: true, required: true },

    jobRole: { type: String, default: "" },
    jobDescription: { type: String, default: "" },

    atsScore: { type: Number, min: 0, max: 100, default: 0 },
    matchPercent: { type: Number, min: 0, max: 100, default: 0 },

    matchedKeywords: { type: [String], default: [] },
    missingKeywords: { type: [String], default: [] },
    recommendedSkills: { type: [String], default: [] },
    suggestions: { type: [String], default: [] },

    summary: { type: String, default: "" }
  },
  { timestamps: true }
);

export const AtsReport = mongoose.model("AtsReport", atsReportSchema);

