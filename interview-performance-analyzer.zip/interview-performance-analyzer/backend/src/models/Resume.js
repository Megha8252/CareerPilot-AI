import mongoose from "mongoose";

const parsedDataSchema = new mongoose.Schema(
  {
    name: { type: String, default: "" },
    email: { type: String, default: "" },
    phone: { type: String, default: "" },
    skills: { type: [String], default: [] },
    education: { type: [String], default: [] },
    experience: { type: [String], default: [] },
    projects: { type: [String], default: [] },
    links: { type: [String], default: [] }
  },
  { _id: false }
);

const resumeSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", index: true, required: true },
    fileName: { type: String, default: "" },
    fileType: { type: String, enum: ["pdf", "docx", "text"], default: "pdf" },
    rawText: { type: String, default: "" },
    parsedData: { type: parsedDataSchema, default: () => ({}) },
    latestAtsScore: { type: Number, min: 0, max: 100, default: 0 }
  },
  { timestamps: true }
);

export const Resume = mongoose.model("Resume", resumeSchema);

