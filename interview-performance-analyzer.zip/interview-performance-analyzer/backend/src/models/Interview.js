import mongoose from "mongoose";

const answerMetricsSchema = new mongoose.Schema(
  {
    clarityScore: { type: Number, min: 0, max: 10, default: 0 },
    confidenceScore: { type: Number, min: 0, max: 10, default: 0 },
    grammarScore: { type: Number, min: 0, max: 10, default: 0 },
    relevanceScore: { type: Number, min: 0, max: 10, default: 0 },
    feedback: { type: String, default: "" },
    improvementTips: { type: [String], default: [] },
    redFlags: { type: [String], default: [] }
  },
  { _id: false }
);

const turnSchema = new mongoose.Schema(
  {
    question: { type: String, required: true },
    answer: { type: String, default: "" },
    responseTimeMs: { type: Number, default: 0 },
    metrics: { type: answerMetricsSchema, default: () => ({}) }
  },
  { timestamps: true }
);

const interviewSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", index: true, required: true },
    domain: {
      type: String,
      enum: ["HR", "DSA", "TECHNICAL", "SYSTEM_DESIGN", "BEHAVIORAL", "CUSTOM"],
      default: "HR"
    },
    mode: { type: String, enum: ["text", "voice"], default: "text" },
    status: { type: String, enum: ["active", "completed"], default: "active" },
    maxQuestions: { type: Number, default: 8 },
    resume: {
      skills: { type: [String], default: [] },
      rawText: { type: String, default: "" }
    },
    // ATS integration (optional)
    resumeId: { type: mongoose.Schema.Types.ObjectId, ref: "Resume" },
    jobRole: { type: String, default: "" },
    jobDescription: { type: String, default: "" },
    atsReportId: { type: mongoose.Schema.Types.ObjectId, ref: "AtsReport" },
    turns: { type: [turnSchema], default: [] },
    startedAt: { type: Date, default: Date.now },
    completedAt: { type: Date }
  },
  { timestamps: true }
);

export const Interview = mongoose.model("Interview", interviewSchema);
