import mongoose from "mongoose";

const reportSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", index: true, required: true },
    interviewId: { type: mongoose.Schema.Types.ObjectId, ref: "Interview", index: true, required: true },
    // Combined scoring (0-100) for ATS + Interview readiness
    interviewScore: { type: Number, min: 0, max: 100, default: 0 },
    atsScore: { type: Number, min: 0, max: 100, default: 0 },
    finalScore: { type: Number, min: 0, max: 100, default: 0 },
    atsReportId: { type: mongoose.Schema.Types.ObjectId, ref: "AtsReport" },
    missingSkills: { type: [String], default: [] },
    strengths: { type: [String], default: [] },
    weaknesses: { type: [String], default: [] },
    suggestions: { type: [String], default: [] },
    finalVerdict: { type: String, default: "Needs Improvement" },
    overallScores: {
      clarity: { type: Number, min: 0, max: 10, default: 0 },
      confidence: { type: Number, min: 0, max: 10, default: 0 },
      grammar: { type: Number, min: 0, max: 10, default: 0 },
      relevance: { type: Number, min: 0, max: 10, default: 0 }
    },
    summary: { type: String, default: "" }
  },
  { timestamps: true }
);

export const Report = mongoose.model("Report", reportSchema);
