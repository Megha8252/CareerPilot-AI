import { z } from "zod";
import { asyncHandler } from "../utils/asyncHandler.js";
import { Interview } from "../models/Interview.js";
import { Report } from "../models/Report.js";
import { Resume } from "../models/Resume.js";
import { AtsReport } from "../models/AtsReport.js";
import {
  evaluateAnswer,
  generateFinalReport,
  generateNextQuestion
} from "../services/interviewAi.js";
import { analyzeAts } from "../services/atsService.js";

export const startInterview = asyncHandler(async (req, res) => {
  const schema = z.object({
    domain: z
      .enum(["HR", "DSA", "TECHNICAL", "SYSTEM_DESIGN", "BEHAVIORAL", "CUSTOM"])
      .default("HR"),
    mode: z.enum(["text", "voice"]).default("text"),
    maxQuestions: z.number().int().min(3).max(20).optional(),
    resumeSkills: z.array(z.string()).optional(),
    resumeText: z.string().optional(),

    // ATS integrated flow (optional)
    resumeId: z.string().optional(),
    jobRole: z.string().optional(),
    jobDescription: z.string().optional(),
    atsReportId: z.string().optional()
  });
  const body = schema.parse(req.body);

  // If resumeId provided, load stored resume and override resumeSkills/resumeText
  let resumeSkills = body.resumeSkills ?? [];
  let resumeText = body.resumeText ?? "";
  let resumeId = body.resumeId;

  if (resumeId) {
    const resume = await Resume.findOne({ _id: resumeId, userId: req.user._id });
    if (!resume) return res.status(404).json({ success: false, message: "Resume not found" });
    resumeSkills = resume.parsedData?.skills || [];
    resumeText = resume.rawText || "";
  }

  const interview = await Interview.create({
    userId: req.user._id,
    domain: body.domain,
    mode: body.mode,
    maxQuestions: body.maxQuestions ?? 8,
    resume: {
      skills: resumeSkills,
      rawText: resumeText
    },
    resumeId: resumeId || undefined,
    jobRole: body.jobRole ?? "",
    jobDescription: body.jobDescription ?? "",
    atsReportId: body.atsReportId || undefined,
    turns: []
  });

  const question = await generateNextQuestion({
    domain: interview.domain,
    turnIndex: 0,
    previousTurns: [],
    resumeSkills: interview.resume.skills,
    jobRole: interview.jobRole,
    jobDescription: interview.jobDescription
  });

  interview.turns.push({ question, answer: "" });
  await interview.save();

  return res.status(201).json({ success: true, interview });
});

export const submitAnswer = asyncHandler(async (req, res) => {
  const schema = z.object({
    answer: z.string().min(1),
    responseTimeMs: z.number().int().min(0).max(30 * 60 * 1000).default(0)
  });
  const { answer, responseTimeMs } = schema.parse(req.body);

  const interview = await Interview.findOne({
    _id: req.params.id,
    userId: req.user._id
  });
  if (!interview) return res.status(404).json({ success: false, message: "Not found" });
  if (interview.status !== "active") {
    return res
      .status(400)
      .json({ success: false, message: "Interview already completed" });
  }

  const currentIndex = interview.turns.length - 1;
  const currentTurn = interview.turns[currentIndex];
  if (!currentTurn) {
    return res.status(400).json({ success: false, message: "Invalid interview state" });
  }

  currentTurn.answer = answer;
  currentTurn.responseTimeMs = responseTimeMs;

  const metrics = await evaluateAnswer({
    domain: interview.domain,
    question: currentTurn.question,
    answer,
    responseTimeMs
  });
  currentTurn.metrics = metrics;

  // If reached max questions, mark completed (report generation is separate endpoint)
  const answeredCount = interview.turns.filter((t) => t.answer && t.answer.trim()).length;
  const done = answeredCount >= interview.maxQuestions;

  let nextQuestion = null;
  if (!done) {
    nextQuestion = await generateNextQuestion({
      domain: interview.domain,
      turnIndex: interview.turns.length,
      previousTurns: interview.turns.map((t) => ({
        question: t.question,
        answer: t.answer
      })),
      resumeSkills: interview.resume.skills,
      jobRole: interview.jobRole,
      jobDescription: interview.jobDescription
    });
    interview.turns.push({ question: nextQuestion, answer: "" });
  } else {
    interview.status = "completed";
    interview.completedAt = new Date();
  }

  await interview.save();

  return res.json({
    success: true,
    interview,
    metrics,
    done
  });
});

export const generateReport = asyncHandler(async (req, res) => {
  const interview = await Interview.findOne({
    _id: req.params.id,
    userId: req.user._id
  });
  if (!interview) return res.status(404).json({ success: false, message: "Not found" });
  if (interview.status !== "completed") {
    return res
      .status(400)
      .json({ success: false, message: "Interview not completed yet" });
  }

  const existing = await Report.findOne({ interviewId: interview._id, userId: req.user._id });
  if (existing) return res.json({ success: true, report: existing, interview });

  const answeredTurns = interview.turns.filter((t) => t.answer && t.answer.trim());
  const reportAi = await generateFinalReport({ domain: interview.domain, turns: answeredTurns });

  const overallScores = averageScores(answeredTurns);

  // InterviewScore: average of 4 metrics scaled to 0-100
  const interviewScore = Math.round(
    ((overallScores.clarity + overallScores.confidence + overallScores.grammar + overallScores.relevance) /
      4) *
      10
  );

  // ATS: if interview has resume + JD info, attach ATS score (create if missing)
  let atsScore = 0;
  let atsReportId = interview.atsReportId || null;
  let missingSkills = [];

  if (interview.resumeId && interview.jobDescription && interview.jobRole) {
    let atsReport = null;
    if (atsReportId) {
      atsReport = await AtsReport.findOne({ _id: atsReportId, userId: req.user._id });
    }
    if (!atsReport) {
      atsReport = await AtsReport.findOne({
        userId: req.user._id,
        resumeId: interview.resumeId,
        jobRole: interview.jobRole
      }).sort({ createdAt: -1 });
    }
    if (!atsReport) {
      const resume = await Resume.findOne({ _id: interview.resumeId, userId: req.user._id });
      if (resume) {
        const analysis = await analyzeAts({
          resumeText: resume.rawText,
          parsedData: resume.parsedData,
          jobRole: interview.jobRole,
          jobDescription: interview.jobDescription
        });
        atsReport = await AtsReport.create({
          userId: req.user._id,
          resumeId: resume._id,
          jobRole: interview.jobRole,
          jobDescription: interview.jobDescription,
          ...analysis
        });
      }
    }

    if (atsReport) {
      atsScore = atsReport.atsScore || 0;
      atsReportId = atsReport._id;
      missingSkills = atsReport.missingKeywords?.slice(0, 12) || [];
    }
  }

  const finalScore = Math.round(interviewScore * 0.55 + atsScore * 0.45);
  const finalVerdict =
    finalScore >= 75 && interviewScore >= 70 && atsScore >= 60 ? "Ready" : "Needs Improvement";
  const report = await Report.create({
    userId: req.user._id,
    interviewId: interview._id,
    strengths: reportAi.strengths,
    interviewScore,
    atsScore,
    finalScore,
    atsReportId,
    missingSkills,
    weaknesses: reportAi.weaknesses,
    suggestions: reportAi.suggestions,
    finalVerdict: reportAi.finalVerdict,
    finalVerdict,
    summary: reportAi.summary,
  });

  return res.status(201).json({ success: true, report, interview });
});


export const listInterviews = asyncHandler(async (req, res) => {
  const interviews = await Interview.find({ userId: req.user._id })
    .sort({ createdAt: -1 })
    .select("-resume.rawText");
  return res.json({ success: true, interviews });
});

export const getInterview = asyncHandler(async (req, res) => {
  const interview = await Interview.findOne({
    _id: req.params.id,
    userId: req.user._id
  }).select("-resume.rawText");
  if (!interview) return res.status(404).json({ success: false, message: "Not found" });
  return res.json({ success: true, interview });
});

function averageScores(turns) {
  const sums = { clarity: 0, confidence: 0, grammar: 0, relevance: 0 };
  const n = Math.max(1, turns.length);
  for (const t of turns) {
    sums.clarity += t.metrics?.clarityScore || 0;
    sums.confidence += t.metrics?.confidenceScore || 0;
    sums.grammar += t.metrics?.grammarScore || 0;
    sums.relevance += t.metrics?.relevanceScore || 0;
  }
  return {
    clarity: round1(sums.clarity / n),
    confidence: round1(sums.confidence / n),
    grammar: round1(sums.grammar / n),
    relevance: round1(sums.relevance / n)
  };
}

function round1(x) {
  return Math.round(x * 10) / 10;
}
