import multer from "multer";
import { z } from "zod";
import { env } from "../config/env.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { Resume } from "../models/Resume.js";
import { AtsReport } from "../models/AtsReport.js";
import { extractText, parseResumeToStructured } from "../services/resumeParsingService.js";
import { analyzeAts } from "../services/atsService.js";
import { generateAtsInterviewQuestions } from "../services/atsQuestionsService.js";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: env.MAX_RESUME_SIZE_BYTES }
});

export const atsUploadMiddleware = upload.single("resume");

export const uploadResume = asyncHandler(async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: "Missing resume file" });
  }

  const allowed = [
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  ];
  if (!allowed.includes(req.file.mimetype)) {
    return res.status(400).json({ success: false, message: "Only PDF/DOCX resumes supported" });
  }

  const rawText = await extractText({ buffer: req.file.buffer, mimeType: req.file.mimetype });
  const parsedData = await parseResumeToStructured(rawText);
  const fileType = req.file.mimetype === "application/pdf" ? "pdf" : "docx";

  const doc = await Resume.create({
    userId: req.user._id,
    fileName: req.file.originalname || "",
    fileType,
    rawText,
    parsedData
  });

  return res.status(201).json({
    success: true,
    resume: {
      id: doc._id,
      fileName: doc.fileName,
      fileType: doc.fileType,
      parsedData: doc.parsedData,
      textPreview: doc.rawText.slice(0, 1500)
    }
  });
});

export const listResumes = asyncHandler(async (req, res) => {
  const resumes = await Resume.find({ userId: req.user._id })
    .sort({ createdAt: -1 })
    .select("-rawText");
  return res.json({ success: true, resumes });
});

export const getResume = asyncHandler(async (req, res) => {
  const resume = await Resume.findOne({ _id: req.params.id, userId: req.user._id });
  if (!resume) return res.status(404).json({ success: false, message: "Not found" });
  return res.json({ success: true, resume });
});

export const analyzeResume = asyncHandler(async (req, res) => {
  const schema = z.object({
    resumeId: z.string().min(1),
    jobRole: z.string().min(1).max(120),
    jobDescription: z.string().min(1).max(20_000)
  });
  const { resumeId, jobRole, jobDescription } = schema.parse(req.body);

  const resume = await Resume.findOne({ _id: resumeId, userId: req.user._id });
  if (!resume) return res.status(404).json({ success: false, message: "Resume not found" });

  const analysis = await analyzeAts({
    resumeText: resume.rawText,
    parsedData: resume.parsedData,
    jobRole,
    jobDescription
  });

  const report = await AtsReport.create({
    userId: req.user._id,
    resumeId: resume._id,
    jobRole,
    jobDescription,
    ...analysis
  });

  resume.latestAtsScore = analysis.atsScore;
  await resume.save();

  return res.status(201).json({ success: true, report });
});

export const listAtsReports = asyncHandler(async (req, res) => {
  const reports = await AtsReport.find({ userId: req.user._id })
    .sort({ createdAt: -1 })
    .limit(50);
  return res.json({ success: true, reports });
});

export const getAtsReport = asyncHandler(async (req, res) => {
  const report = await AtsReport.findOne({ _id: req.params.id, userId: req.user._id });
  if (!report) return res.status(404).json({ success: false, message: "Not found" });
  return res.json({ success: true, report });
});

export const matchJob = asyncHandler(async (req, res) => {
  const schema = z.object({
    resumeId: z.string().min(1),
    jobRole: z.string().min(1).max(120),
    jobDescription: z.string().min(1).max(20_000)
  });
  const { resumeId, jobRole, jobDescription } = schema.parse(req.body);

  const resume = await Resume.findOne({ _id: resumeId, userId: req.user._id }).select(
    "rawText parsedData"
  );
  if (!resume) return res.status(404).json({ success: false, message: "Resume not found" });

  const analysis = await analyzeAts({
    resumeText: resume.rawText,
    parsedData: resume.parsedData,
    jobRole,
    jobDescription
  });

  return res.json({
    success: true,
    matchPercent: analysis.matchPercent,
    matchedKeywords: analysis.matchedKeywords,
    missingKeywords: analysis.missingKeywords,
    recommendedSkills: analysis.recommendedSkills
  });
});

export const generateQuestions = asyncHandler(async (req, res) => {
  const schema = z.object({
    resumeId: z.string().min(1),
    jobRole: z.string().min(1).max(120),
    jobDescription: z.string().min(1).max(20_000),
    types: z.array(z.enum(["HR", "TECHNICAL", "BEHAVIORAL"])).optional(),
    count: z.number().int().min(3).max(20).default(8)
  });
  const { resumeId, jobRole, jobDescription, types, count } = schema.parse(req.body);

  const resume = await Resume.findOne({ _id: resumeId, userId: req.user._id });
  if (!resume) return res.status(404).json({ success: false, message: "Resume not found" });

  const questions = await generateAtsInterviewQuestions({
    resumeText: resume.rawText,
    parsedData: resume.parsedData,
    jobRole,
    jobDescription,
    types: types?.length ? types : ["HR", "TECHNICAL", "BEHAVIORAL"],
    count
  });

  return res.json({ success: true, questions });
});

