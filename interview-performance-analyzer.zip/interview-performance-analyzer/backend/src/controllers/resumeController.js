import multer from "multer";
import { asyncHandler } from "../utils/asyncHandler.js";
import { env } from "../config/env.js";
import { extractSkillsFromResumeText } from "../services/resumeService.js";
import { extractText } from "../services/resumeParsingService.js";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: env.MAX_RESUME_SIZE_BYTES }
});

export const resumeUploadMiddleware = upload.single("resume");

export const parseResume = asyncHandler(async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: "Missing resume file" });
  }
  const allowed = [
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  ];
  if (!allowed.includes(req.file.mimetype)) {
    return res.status(400).json({ success: false, message: "Only PDF/DOCX resumes supported" });
  }

  const text = await extractText({ buffer: req.file.buffer, mimeType: req.file.mimetype });
  const skills = await extractSkillsFromResumeText(text);

  return res.json({
    success: true,
    resume: { textPreview: text.slice(0, 1500), skills, rawText: text }
  });
});
