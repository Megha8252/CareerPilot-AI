import { asyncHandler } from "../utils/asyncHandler.js";
import { Report } from "../models/Report.js";
import { Interview } from "../models/Interview.js";

export const getReport = asyncHandler(async (req, res) => {
  const report = await Report.findOne({ _id: req.params.id, userId: req.user._id });
  if (!report) return res.status(404).json({ success: false, message: "Not found" });
  return res.json({ success: true, report });
});

export const getLatestReportForInterview = asyncHandler(async (req, res) => {
  const interview = await Interview.findOne({
    _id: req.params.interviewId,
    userId: req.user._id
  });
  if (!interview) return res.status(404).json({ success: false, message: "Not found" });

  const report = await Report.findOne({ interviewId: interview._id, userId: req.user._id }).sort({
    createdAt: -1
  });
  if (!report) return res.status(404).json({ success: false, message: "Report not found" });
  return res.json({ success: true, report });
});

export const dashboardStats = asyncHandler(async (req, res) => {
  const [interviews, reports] = await Promise.all([
    Interview.find({ userId: req.user._id }).sort({ createdAt: -1 }).limit(20),
    Report.find({ userId: req.user._id }).sort({ createdAt: -1 }).limit(20)
  ]);

  const scoreTimeline = reports
    .slice()
    .reverse()
    .map((r) => ({
      date: r.createdAt.toISOString().slice(0, 10),
      clarity: r.overallScores?.clarity ?? 0,
      confidence: r.overallScores?.confidence ?? 0,
      grammar: r.overallScores?.grammar ?? 0,
      relevance: r.overallScores?.relevance ?? 0
    }));

  return res.json({
    success: true,
    totals: {
      interviews: interviews.length,
      reports: reports.length
    },
    scoreTimeline
  });
});

