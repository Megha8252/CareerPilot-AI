import { aiJson } from "./openaiService.js";

// Main ATS analysis entrypoint. Returns an object that matches AtsReport fields:
// { atsScore, matchPercent, matchedKeywords, missingKeywords, recommendedSkills, suggestions, summary }
export async function analyzeAts({ resumeText, parsedData, jobRole, jobDescription }) {
  // 1) Keywords extraction (AI if available, fallback otherwise)
  const keywords = await extractKeywords(jobRole, jobDescription);

  // 2) Matching
  const resumeLower = String(resumeText || "").toLowerCase();
  const matched = [];
  const missing = [];
  for (const kw of keywords) {
    const k = kw.toLowerCase();
    if (k.length < 2) continue;
    if (resumeLower.includes(k)) matched.push(kw);
    else missing.push(kw);
  }

  const matchPercent = keywords.length ? Math.round((matched.length / keywords.length) * 100) : 0;

  // 3) Completeness and formatting heuristics
  const completeness = sectionCompletenessScore(parsedData); // 0..25
  const formatting = formattingScore(resumeText); // 0..15
  const relevance = experienceRelevanceScore(parsedData, keywords); // 0..10
  const keywordScore = Math.round((matchPercent / 100) * 50); // 0..50

  let atsScore = keywordScore + completeness + formatting + relevance;
  atsScore = clamp(atsScore, 0, 100);

  const recommendedSkills = missing.slice(0, 12);
  const suggestions = buildSuggestions({ missingKeywords: missing, parsedData, resumeText });
  const summary = buildSummary({ atsScore, matchPercent, missingKeywords: missing });

  return {
    atsScore,
    matchPercent,
    matchedKeywords: matched.slice(0, 40),
    missingKeywords: missing.slice(0, 40),
    recommendedSkills,
    suggestions,
    summary
  };
}

async function extractKeywords(jobRole, jobDescription) {
  const prompt = `
Extract the most important ATS keywords for this job.
Return JSON: {"keywords": ["..."]} (10-35 keywords).

Job role: ${jobRole}
Job description:
${jobDescription.slice(0, 12000)}
`;
  const data = await aiJson(prompt, {
    system: "Return ONLY JSON with key 'keywords' (string array)."
  });
  if (data?.keywords && Array.isArray(data.keywords) && data.keywords.length) {
    return uniq(data.keywords.map(String).map((s) => s.trim()).filter(Boolean)).slice(0, 35);
  }
  return fallbackKeywords(jobRole, jobDescription);
}

function fallbackKeywords(jobRole, jd) {
  const stop = new Set([
    "the",
    "and",
    "or",
    "to",
    "a",
    "of",
    "in",
    "for",
    "with",
    "on",
    "is",
    "are",
    "as",
    "we",
    "you",
    "your",
    "will",
    "be",
    "this",
    "that",
    "by",
    "an",
    "at"
  ]);
  const tokens = String(jd || "")
    .toLowerCase()
    .replace(/[^a-z0-9+#.\s]/g, " ")
    .split(/\s+/)
    .filter((t) => t.length >= 3 && t.length <= 20 && !stop.has(t));

  const freq = new Map();
  for (const t of tokens) freq.set(t, (freq.get(t) || 0) + 1);
  const ranked = [...freq.entries()].sort((a, b) => b[1] - a[1]).map((x) => x[0]);

  const roleTokens = String(jobRole || "")
    .toLowerCase()
    .replace(/[^a-z0-9+#.\s]/g, " ")
    .split(/\s+/)
    .filter(Boolean);

  return uniq([...roleTokens, ...ranked]).slice(0, 25);
}

function sectionCompletenessScore(parsedData) {
  const pd = parsedData || {};
  const hasSkills = Array.isArray(pd.skills) && pd.skills.length >= 5;
  const hasEdu = Array.isArray(pd.education) && pd.education.length >= 1;
  const hasExp = Array.isArray(pd.experience) && pd.experience.length >= 1;
  const hasProjects = Array.isArray(pd.projects) && pd.projects.length >= 1;
  const hasName = Boolean(String(pd.name || "").trim());

  const parts = [
    hasName ? 4 : 0,
    hasSkills ? 9 : 3,
    hasEdu ? 5 : 0,
    hasExp ? 5 : 0,
    hasProjects ? 2 : 0
  ];

  return clamp(parts.reduce((a, b) => a + b, 0), 0, 25);
}

function formattingScore(text) {
  const t = String(text || "");
  const lines = t.split("\n").map((l) => l.trim());
  const len = t.length;
  const bullets = lines.filter((l) => /^[-•\u2022]/.test(l)).length;
  const hasBullets = bullets >= 5;
  const goodLength = len >= 1200 && len <= 12000;
  const hasHeadings =
    /education/i.test(t) && /experience/i.test(t) && /skills/i.test(t);

  let score = 0;
  if (goodLength) score += 6;
  if (hasBullets) score += 5;
  if (hasHeadings) score += 4;
  return clamp(score, 0, 15);
}

function experienceRelevanceScore(parsedData, keywords) {
  const exp = (parsedData?.experience || []).join(" ").toLowerCase();
  if (!exp.trim() || !keywords?.length) return 0;
  let hits = 0;
  for (const kw of keywords) {
    const k = String(kw).toLowerCase();
    if (k.length < 3) continue;
    if (exp.includes(k)) hits++;
  }
  const ratio = hits / Math.max(1, keywords.length);
  return clamp(Math.round(ratio * 10), 0, 10);
}

function buildSuggestions({ missingKeywords, parsedData, resumeText }) {
  const out = [];
  if (missingKeywords.length) {
    out.push(
      `Add missing keywords where relevant: ${missingKeywords.slice(0, 8).join(", ")}.`
    );
  }

  const pd = parsedData || {};
  if (!pd.education?.length) out.push("Add an Education section with degree, college, and dates.");
  if (!pd.experience?.length)
    out.push("Add an Experience section with measurable impact (numbers, results).");
  if (!pd.projects?.length) out.push("Add 1–3 projects with tech stack and outcomes.");
  if (!(pd.skills?.length >= 5)) out.push("Add a Skills section with 10–20 targeted skills.");

  const t = String(resumeText || "");
  const bullets = t.split("\n").filter((l) => /^[-•\u2022]/.test(l.trim())).length;
  if (bullets < 5) out.push("Use bullet points for responsibilities and achievements.");

  // Keep concise
  return uniq(out).slice(0, 8);
}

function buildSummary({ atsScore, matchPercent, missingKeywords }) {
  if (atsScore >= 80) return `Strong ATS readiness (${atsScore}/100) with ${matchPercent}% match.`;
  if (atsScore >= 60)
    return `Moderate ATS readiness (${atsScore}/100) with ${matchPercent}% match. Improve missing keywords and sections.`;
  return `Low ATS readiness (${atsScore}/100) with ${matchPercent}% match. Add missing sections and targeted keywords.`;
}

function uniq(arr) {
  const seen = new Set();
  const out = [];
  for (const x of arr) {
    const k = String(x).toLowerCase();
    if (!k.trim() || seen.has(k)) continue;
    seen.add(k);
    out.push(String(x));
  }
  return out;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}
