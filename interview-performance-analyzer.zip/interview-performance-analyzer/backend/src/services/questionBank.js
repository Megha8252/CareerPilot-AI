export const questionBank = {
  HR: [
    "Tell me about yourself.",
    "Why do you want this role?",
    "What is your biggest strength and biggest weakness?",
    "Describe a time you handled conflict in a team.",
    "Where do you see yourself in 3 years?"
  ],
  DSA: [
    "Explain the difference between arrays and linked lists and when to use each.",
    "What is the time complexity of binary search, and why?",
    "How would you detect a cycle in a linked list?",
    "Explain hashing and what causes collisions.",
    "Given an array, how do you find the maximum subarray sum?"
  ],
  TECHNICAL: [
    "Explain REST vs GraphQL and when you'd choose each.",
    "What is a race condition and how can you prevent it?",
    "Explain the concept of caching and common strategies.",
    "What are indexes in databases and how do they help?",
    "Explain CAP theorem in distributed systems."
  ],
  SYSTEM_DESIGN: [
    "Design a URL shortener. What components and trade-offs would you consider?",
    "Design a rate limiter for an API.",
    "Design a chat application with online presence.",
    "Design a news feed system like Instagram.",
    "Design a file storage service like Google Drive."
  ],
  BEHAVIORAL: [
    "Tell me about a time you failed and what you learned.",
    "Tell me about a time you led a project.",
    "How do you handle tight deadlines?",
    "Describe a time you received critical feedback.",
    "Describe a time you had to learn something quickly."
  ]
};

export function pickFallbackQuestion(domain, idx) {
  const list = questionBank[domain] || questionBank.HR;
  return list[idx % list.length];
}

