import { aiJson } from "./openaiService.js";
import { extractText } from "./resumeParsingService.js";

export async function extractTextFromPdf(buffer) {
  // Backwards-compatible wrapper used by existing /resume/parse endpoint
  return extractText({ buffer, mimeType: "application/pdf" });
}

export async function extractSkillsFromResumeText(text) {
  const prompt = `
Extract a concise list of skills (tools, languages, frameworks, domains) from this resume text.
Return JSON: {"skills": ["..."]} (max 25 skills).

Resume text:
${text.slice(0, 8000)}
`;

  const data = await aiJson(prompt, {
    system: "Return ONLY JSON {\"skills\": string[]}."
  });

  if (!data?.skills || !Array.isArray(data.skills)) return [];
  return data.skills.map(String).map((s) => s.trim()).filter(Boolean).slice(0, 25);
}
