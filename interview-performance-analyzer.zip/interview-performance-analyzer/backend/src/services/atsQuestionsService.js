import { aiJson } from "./openaiService.js";

export async function generateAtsInterviewQuestions({
  resumeText,
  parsedData,
  jobRole,
  jobDescription,
  types,
  count
}) {
  const prompt = `
Generate interview questions tailored to the candidate resume and job role.
Return JSON: {"questions":[{"type":"HR"|"TECHNICAL"|"BEHAVIORAL","question":"..."}]}

Job role: ${jobRole}
Job description:
${jobDescription.slice(0, 6000)}

Candidate resume (summary):
Name: ${parsedData?.name || ""}
Skills: ${(parsedData?.skills || []).slice(0, 20).join(", ")}
Experience: ${(parsedData?.experience || []).slice(0, 6).join(" | ")}
Projects: ${(parsedData?.projects || []).slice(0, 6).join(" | ")}

Resume raw text (truncated):
${String(resumeText || "").slice(0, 6000)}

Constraints:
- total questions: ${count}
- include types: ${types.join(", ")}
- keep questions short and practical
- ensure at least 2 questions reference specific resume items (projects/skills)
`;

  const data = await aiJson(prompt, {
    system: "Return ONLY JSON as specified, no markdown."
  });

  if (data?.questions && Array.isArray(data.questions) && data.questions.length) {
    return data.questions
      .map((q) => ({
        type: q.type === "TECHNICAL" || q.type === "BEHAVIORAL" ? q.type : "HR",
        question: String(q.question || "").trim()
      }))
      .filter((q) => q.question)
      .slice(0, count);
  }

  // Fallback templates (no AI key)
  const skill = (parsedData?.skills || [])[0] || jobRole;
  const project = (parsedData?.projects || [])[0] || "a recent project";
  const base = [
    { type: "HR", question: `Tell me about yourself and why you want the ${jobRole} role.` },
    { type: "BEHAVIORAL", question: "Describe a time you handled a tight deadline." },
    { type: "TECHNICAL", question: `Explain a concept you used in ${project}.` },
    { type: "TECHNICAL", question: `What are best practices when working with ${skill}?` },
    { type: "BEHAVIORAL", question: "Tell me about a time you disagreed with a teammate." },
    { type: "HR", question: "What is your biggest strength and weakness?" }
  ];

  return base.filter((q) => types.includes(q.type)).slice(0, count);
}

