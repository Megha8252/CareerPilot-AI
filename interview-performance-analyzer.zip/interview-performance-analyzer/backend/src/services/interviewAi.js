import { aiJson } from "./openaiService.js";
import { pickFallbackQuestion } from "./questionBank.js";

export async function generateNextQuestion({
  domain,
  turnIndex,
  previousTurns,
  resumeSkills = [],
  jobRole = "",
  jobDescription = ""
}) {
  const prompt = `
You are conducting a ${domain} mock interview.

Resume skills (if any): ${resumeSkills.length ? resumeSkills.join(", ") : "N/A"}
Target job role: ${jobRole || "N/A"}
Job description (if provided):
${jobDescription ? jobDescription.slice(0, 2000) : "N/A"}

Previous turns (Q/A):
${previousTurns
  .map((t, i) => `Q${i + 1}: ${t.question}\nA${i + 1}: ${t.answer || ""}`)
  .join("\n\n")}

Generate the NEXT interview question as JSON:
{
  "question": "..."
}

Rules:
- Ask ONE question only.
- Keep it concise and realistic.
- Increase difficulty gradually.
- If resume skills exist, ask at least 1 question specifically about them across the interview.
- If job role/JD exists, tailor questions to role requirements.
`;

  const data = await aiJson(prompt, {
    system:
      "You are a professional interviewer. Return ONLY JSON: {\"question\": string}."
  });

  if (data?.question && typeof data.question === "string") return data.question.trim();
  return pickFallbackQuestion(domain, turnIndex);
}

export async function evaluateAnswer({
  domain,
  question,
  answer,
  responseTimeMs
}) {
  const prompt = `
You are evaluating a candidate answer in a ${domain} interview.

Question: ${question}
Answer: ${answer}
Response time (ms): ${responseTimeMs}

Return JSON with:
{
  "clarityScore": number (0-10),
  "confidenceScore": number (0-10),
  "grammarScore": number (0-10),
  "relevanceScore": number (0-10),
  "feedback": "short paragraph",
  "improvementTips": ["tip1", "tip2"],
  "redFlags": ["..."]
}

Scoring guidance:
- Clarity: structure, concise, understandable.
- Confidence: directness, ownership, no excessive hedging.
- Grammar: grammar, fluency.
- Relevance: addresses the question.
`;

  const data = await aiJson(prompt, {
    system:
      "You are a strict interview coach. Return ONLY JSON with the required keys and types."
  });

  // Fallback: simple heuristic if AI is disabled
  if (!data) {
    const len = (answer || "").trim().length;
    const base = Math.max(2, Math.min(8, Math.round(len / 80)));
    return {
      clarityScore: base,
      confidenceScore: base,
      grammarScore: base,
      relevanceScore: base,
      feedback:
        "AI evaluation is disabled. Provide an OpenAI API key to enable detailed feedback.",
      improvementTips: [
        "Structure your answer with a clear beginning, middle, and end.",
        "Give a concrete example and quantify impact where possible."
      ],
      redFlags: []
    };
  }

  return {
    clarityScore: clamp01to10(data.clarityScore),
    confidenceScore: clamp01to10(data.confidenceScore),
    grammarScore: clamp01to10(data.grammarScore),
    relevanceScore: clamp01to10(data.relevanceScore),
    feedback: String(data.feedback || "").trim(),
    improvementTips: Array.isArray(data.improvementTips)
      ? data.improvementTips.map(String).slice(0, 6)
      : [],
    redFlags: Array.isArray(data.redFlags) ? data.redFlags.map(String).slice(0, 6) : []
  };
}

export async function generateFinalReport({ domain, turns }) {
  const prompt = `
You are generating a structured interview performance report for a ${domain} mock interview.

Turns:
${turns
  .map(
    (t, i) =>
      `Q${i + 1}: ${t.question}\nA${i + 1}: ${t.answer}\nScores: clarity=${t.metrics.clarityScore}, confidence=${t.metrics.confidenceScore}, grammar=${t.metrics.grammarScore}, relevance=${t.metrics.relevanceScore}\nFeedback: ${t.metrics.feedback}`
  )
  .join("\n\n")}

Return JSON:
{
  "strengths": ["..."],
  "weaknesses": ["..."],
  "suggestions": ["..."],
  "finalVerdict": "Ready" | "Needs Improvement",
  "summary": "1-3 sentences"
}
`;

  const data = await aiJson(prompt, {
    system:
      "You are an expert interview coach. Return ONLY JSON with the required keys."
  });

  if (!data) {
    return {
      strengths: ["Completed the mock interview flow successfully."],
      weaknesses: ["AI report generation is disabled without an OpenAI API key."],
      suggestions: [
        "Add OPENAI_API_KEY to enable detailed strengths/weaknesses analysis."
      ],
      finalVerdict: "Needs Improvement",
      summary:
        "AI report generation is disabled. Configure the OpenAI key for full report output."
    };
  }

  return {
    strengths: Array.isArray(data.strengths) ? data.strengths.map(String).slice(0, 8) : [],
    weaknesses: Array.isArray(data.weaknesses)
      ? data.weaknesses.map(String).slice(0, 8)
      : [],
    suggestions: Array.isArray(data.suggestions)
      ? data.suggestions.map(String).slice(0, 10)
      : [],
    finalVerdict:
      data.finalVerdict === "Ready" ? "Ready" : "Needs Improvement",
    summary: String(data.summary || "").trim()
  };
}

function clamp01to10(n) {
  const x = Number(n);
  if (!Number.isFinite(x)) return 0;
  return Math.max(0, Math.min(10, Math.round(x * 10) / 10));
}
