import pdf from "pdf-parse";
import mammoth from "mammoth";
import { aiJson } from "./openaiService.js";

export async function extractText({ buffer, mimeType }) {
  if (mimeType === "application/pdf") {
    const data = await pdf(buffer);
    return normalize(data.text || "");
  }
  if (
    mimeType ===
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  ) {
    const { value } = await mammoth.extractRawText({ buffer });
    return normalize(value || "");
  }
  // Fallback: treat as plain text
  return normalize(buffer.toString("utf-8"));
}

export async function parseResumeToStructured(rawText) {
  const prompt = `
Extract structured resume information from the text below.
Return JSON:
{
  "name": "",
  "email": "",
  "phone": "",
  "skills": ["..."],
  "education": ["..."],
  "experience": ["..."],
  "projects": ["..."],
  "links": ["..."]
}

Rules:
- Keep arrays concise (max 12 each).
- Use empty string/empty array if unknown.

Resume text:
${rawText.slice(0, 12000)}
`;

  const data = await aiJson(prompt, {
    system: "Return ONLY valid JSON with the specified keys."
  });

  if (!data) return heuristicParse(rawText);

  return {
    name: String(data.name || "").trim(),
    email: String(data.email || "").trim(),
    phone: String(data.phone || "").trim(),
    skills: arrayOfStrings(data.skills, 25),
    education: arrayOfStrings(data.education, 12),
    experience: arrayOfStrings(data.experience, 12),
    projects: arrayOfStrings(data.projects, 12),
    links: arrayOfStrings(data.links, 10)
  };
}

function arrayOfStrings(x, max) {
  if (!Array.isArray(x)) return [];
  return x.map(String).map((s) => s.trim()).filter(Boolean).slice(0, max);
}

function normalize(s) {
  return String(s).replace(/\r/g, "").replace(/[ \t]+\n/g, "\n").trim();
}

function heuristicParse(text) {
  const emailMatch = text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
  const phoneMatch = text.match(/(\+?\d[\d\s\-()]{8,}\d)/);
  const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
  const name = lines[0] && lines[0].length <= 60 ? lines[0] : "";

  const skills = extractSection(lines, ["skills", "technical skills", "tools"]);
  const education = extractSection(lines, ["education", "academics"]);
  const experience = extractSection(lines, ["experience", "work experience", "employment"]);
  const projects = extractSection(lines, ["projects", "project"]);
  const links = lines
    .filter((l) => l.includes("http://") || l.includes("https://") || l.includes("linkedin.com") || l.includes("github.com"))
    .slice(0, 10);

  return {
    name,
    email: emailMatch ? emailMatch[0] : "",
    phone: phoneMatch ? phoneMatch[0] : "",
    skills: toKeywords(skills.join(" ")).slice(0, 25),
    education: education.slice(0, 12),
    experience: experience.slice(0, 12),
    projects: projects.slice(0, 12),
    links
  };
}

function extractSection(lines, titles) {
  const idx = lines.findIndex((l) => titles.includes(l.toLowerCase()));
  if (idx === -1) return [];
  const out = [];
  for (let i = idx + 1; i < lines.length; i++) {
    const l = lines[i];
    if (l.length <= 40 && /^[A-Za-z][A-Za-z\s/&-]{0,30}$/.test(l) && l.toLowerCase() === l) {
      // too heuristic; ignore
    }
    // stop when next likely heading
    if (isHeading(l, titles)) break;
    if (out.length >= 14) break;
    out.push(l.replace(/^[-•\u2022]\s*/, ""));
  }
  return out;
}

function isHeading(line, currentTitles) {
  const x = line.toLowerCase();
  const headings = [
    "skills",
    "technical skills",
    "tools",
    "education",
    "academics",
    "experience",
    "work experience",
    "employment",
    "projects",
    "project",
    "certifications",
    "achievements"
  ];
  return headings.includes(x) && !currentTitles.includes(x);
}

function toKeywords(s) {
  return String(s)
    .split(/[,|/•\u2022]\s*|\s{2,}/)
    .map((x) => x.trim())
    .filter((x) => x.length >= 2 && x.length <= 40)
    .slice(0, 50);
}

