import OpenAI from "openai";
import { env } from "../config/env.js";

function hasKey() {
  return Boolean(env.OPENAI_API_KEY && env.OPENAI_API_KEY.trim());
}

function client() {
  return new OpenAI({ apiKey: env.OPENAI_API_KEY });
}

export async function aiJson(prompt, { system, temperature = 0.4 } = {}) {
  if (!hasKey()) return null;

  const openai = client();
  const resp = await openai.chat.completions.create({
    model: env.OPENAI_MODEL,
    temperature,
    response_format: { type: "json_object" },
    messages: [
      {
        role: "system",
        content:
          system ||
          "You are a precise assistant. Return ONLY valid JSON. Do not include markdown."
      },
      { role: "user", content: prompt }
    ]
  });

  const content = resp.choices?.[0]?.message?.content || null;
  if (!content) return null;
  try {
    return JSON.parse(content);
  } catch (e) {
    return null;
  }
}

